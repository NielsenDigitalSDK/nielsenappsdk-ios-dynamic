//
//  NielsenAppApi-umbrella.h
//  NielsenAppApi
//
//  Created by Mike Petrov on 22/11/2018.
//  Copyright © 2018 Nielsen. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NielsenAppApi.
FOUNDATION_EXPORT double NielsenAppApiVersionNumber;

//! Project version string for NielsenAppApi.
FOUNDATION_EXPORT const unsigned char NielsenAppApiVersionString[];

#import "NielsenAppApi.h"
#import "NielsenEventTracker.h"
#import "NielsenAppSDKJSHandler.h"


